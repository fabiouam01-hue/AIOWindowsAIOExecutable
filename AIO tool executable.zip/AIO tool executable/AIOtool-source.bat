@echo off
title All-in-One Windows System & Network Fixer
color 0B

:: Check for Administrator privileges
fltmc >nul 2>&1
if %errorLevel% neq 0 (
    color 0C
    echo ========================================================
    echo   [ERROR] Administrator privileges required!
    echo   Please right-click this file and select:
    echo   "Run as administrator"
    echo ========================================================
    pause
    exit /b
)

:MENU
cls
color 0B
echo ========================================================
echo          ALL-IN-ONE WINDOWS TOOL FIXER
echo ========================================================
echo.
echo   [1] Harden Firewall ^& Close Unsafe Ports
echo   [2] Fix Mouse Cursor Size (Reset to Default)
echo   [3] Optimize RAM ^& Memory Management
echo   [4] Reset ^& Optimize Network Connectivity
echo   [5] Optimize Windows Startup Performance
echo   [6] Optimize Windows Registry (Safe Performance Tweaks)
echo   [7] RUN ALL FIXES (1 through 6)
echo   [0] Exit
echo.
echo ========================================================
set /p choice="Select an option (0-7): "

if "%choice%"=="1" goto FIREWALL
if "%choice%"=="2" goto CURSOR
if "%choice%"=="3" goto RAM
if "%choice%"=="4" goto NETWORK
if "%choice%"=="5" goto STARTUP
if "%choice%"=="6" goto REGISTRY
if "%choice%"=="7" goto RUN_ALL
if "%choice%"=="0" exit /b

echo.
echo [!] Invalid selection. Please try again.
timeout /t 2 >nul
goto MENU

:: ========================================================
:: MODULE 1: FIREWALL HARDENING
:: ========================================================
:FIREWALL
cls
color 0C
echo ========================================================
echo      [1/6] HARDENING FIREWALL ^& CLOSING UNSAFE PORTS
echo ========================================================
echo.

echo - Setting default policy to Block Inbound and Allow Outbound...
netsh advfirewall set allprofiles firewallpolicy blockinbound,allowoutbound >nul

echo - Blocking common high-risk remote access/legacy ports (TCP)...
netsh advfirewall firewall delete rule name="BLOCK_UNSAFE_TCP" >nul 2>&1
netsh advfirewall firewall add rule name="BLOCK_UNSAFE_TCP" dir=in action=block protocol=TCP localport=21,22,23,25,110,135,137,138,139,445,1433,1434,3306,3389,5900,5985,5986 >nul

echo - Blocking common high-risk discovery/legacy ports (UDP)...
netsh advfirewall firewall delete rule name="BLOCK_UNSAFE_UDP" >nul 2>&1
netsh advfirewall firewall add rule name="BLOCK_UNSAFE_UDP" dir=in action=block protocol=UDP localport=69,135,137,138,139,161,162,445,1434,1900,5353 >nul

echo - Disabling ICMP Echo Requests (Ping) on Public networks...
netsh advfirewall firewall delete rule name="BLOCK_PING_PUBLIC" >nul 2>&1
netsh advfirewall firewall add rule name="BLOCK_PING_PUBLIC" dir=in action=block protocol=icmpv4:8,any profile=public >nul

echo.
echo [OK] Firewall hardening complete!
if "%run_all%"=="1" goto :eof
echo.
pause
goto MENU

:: ========================================================
:: MODULE 2: MOUSE CURSOR FIX
:: ========================================================
:CURSOR
cls
color 0E
echo ========================================================
echo      [2/6] RESETTING MOUSE CURSOR SIZE TO DEFAULT
echo ========================================================
echo.

echo - Updating Registry cursor base size to 32...
reg add "HKCU\Control Panel\Cursors" /v CursorBaseSize /t REG_DWORD /d 32 /f >nul 2>&1

echo - Reloading user parameters to apply immediately...
powershell -NoProfile -Command "$code = '[DllImport(\"user32.dll\", SetLastError = true)] public static extern bool SystemParametersInfo(uint uiAction, uint uiParam, IntPtr pvParam, uint fWinIni);'; $type = Add-Type -MemberDefinition $code -Name 'Win32' -Namespace 'Native' -PassThru; $type::SystemParametersInfo(0x0057, 0, [IntPtr]::Zero, 3)" >nul 2>&1

echo.
echo [OK] Mouse cursor size has been reset!
if "%run_all%"=="1" goto :eof
echo.
pause
goto MENU

:: ========================================================
:: MODULE 3: RAM & MEMORY OPTIMIZER
:: ========================================================
:RAM
cls
color 0A
echo ========================================================
echo      [3/6] OPTIMIZING WINDOWS MEMORY MANAGEMENT
echo ========================================================
echo.

echo - Resetting SysMain (Superfetch) memory caching service...
net stop SysMain >nul 2>&1
timeout /t 2 /nobreak >nul
net start SysMain >nul 2>&1

echo - Flushing DNS Resolver Cache...
ipconfig /flushdns >nul 2>&1

echo - Cleaning temporary system and user files...
del /s /f /q "%temp%\*.*" >nul 2>&1
for /d %%p in ("%temp%\*.*") do rmdir "%%p" /s /q >nul 2>&1
del /s /f /q "C:\Windows\Temp\*.*" >nul 2>&1
for /d %%p in ("C:\Windows\Temp\*.*") do rmdir "%%p" /s /q >nul 2>&1

echo - Releasing unused RAM from background processes...
powershell -NoProfile -Command "Get-Process | ForEach-Object { try { $_.MinWorkingSet = $_.MinWorkingSet } catch {} }" >nul 2>&1

echo.
echo [OK] Memory optimization complete!
if "%run_all%"=="1" goto :eof
echo.
pause
goto MENU

:: ========================================================
:: MODULE 4: NETWORK RESET & OPTIMIZER
:: ========================================================
:NETWORK
cls
color 0A
echo ========================================================
echo      [4/6] OPTIMIZING AND RESETTING NETWORK SETTINGS
echo ========================================================
echo.

echo - Flushing DNS resolver cache...
ipconfig /flushdns >nul

echo - Clearing ARP and NetBIOS caches...
arp -d * >nul 2>&1
nbtstat -R >nul 2>&1
nbtstat -RR >nul 2>&1

echo - Releasing and renewing IP address...
ipconfig /release >nul
ipconfig /renew >nul
ipconfig /registerdns >nul

echo - Resetting Winsock catalog...
netsh winsock reset >nul

echo - Resetting TCP/IP stack...
netsh int ip reset >nul
netsh int ipv6 reset >nul

echo - Enabling TCP Receive Window Auto-Tuning...
netsh int tcp set global autotuninglevel=normal >nul

echo.
echo [OK] Network reset complete! (A PC restart is recommended)
if "%run_all%"=="1" goto :eof
echo.
pause
goto MENU

:: ========================================================
:: MODULE 5: STARTUP OPTIMIZER
:: ========================================================
:STARTUP
cls
color 0D
echo ========================================================
echo      [5/6] OPTIMIZING WINDOWS STARTUP PERFORMANCE
echo ========================================================
echo.

echo - Enabling Windows Fast Startup...
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Power" /v HiberbootEnabled /t REG_DWORD /d 1 /f >nul

echo - Removing artificial startup delay for desktop apps...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize" /v StartupDelayInMSec /t REG_DWORD /d 0 /f >nul

echo - Disabling heavy background telemetry services...
sc config "DiagTrack" start= disabled >nul
sc stop "DiagTrack" >nul 2>&1
sc config "dmwappushservice" start= disabled >nul
sc stop "dmwappushservice" >nul 2>&1

echo - Switching non-essential services to Manual start...
sc config "MapsBroker" start= demand >nul
sc config "lfsvc" start= demand >nul
sc config "RetailDemo" start= demand >nul
sc config "WMPNetworkSvc" start= demand >nul

echo - Clearing temporary boot and cache files...
del /s /f /q "%temp%\*.*" >nul 2>&1
for /d %%p in ("%temp%\*.*") do rmdir "%%p" /s /q >nul 2>&1
del /s /f /q "C:\Windows\Temp\*.*" >nul 2>&1
for /d %%p in ("C:\Windows\Temp\*.*") do rmdir "%%p" /s /q >nul 2>&1

echo.
echo [OK] Startup optimization complete! (A PC restart is recommended)
if "%run_all%"=="1" goto :eof
echo.
pause
goto MENU

:: ========================================================
:: MODULE 6: REGISTRY OPTIMIZER
:: ========================================================
:REGISTRY
cls
color 0B
echo ========================================================
echo      [6/6] WINDOWS REGISTRY PERFORMANCE OPTIMIZER
echo ========================================================
echo.

echo - Backing up Registry to Desktop...
reg export HKLM "%USERPROFILE%\Desktop\HKLM_Backup.reg" /y >nul 2>&1
reg export HKCU "%USERPROFILE%\Desktop\HKCU_Backup.reg" /y >nul 2>&1
echo   (Backup saved to your Desktop)

echo - Optimizing UI and Shutdown Responsiveness...
reg add "HKCU\Control Panel\Desktop" /v "MenuShowDelay" /t REG_SZ /d "100" /f >nul
reg add "HKCU\Control Panel\Desktop" /v "AutoEndTasks" /t REG_SZ /d "1" /f >nul
reg add "HKCU\Control Panel\Desktop" /v "HungAppTimeout" /t REG_SZ /d "2000" /f >nul
reg add "HKCU\Control Panel\Desktop" /v "WaitToKillAppTimeout" /t REG_SZ /d "3000" /f >nul
reg add "HKLM\SYSTEM\CurrentControlSet\Control" /v "WaitToKillServiceTimeout" /t REG_SZ /d "3000" /f >nul

echo - Optimizing Gaming and Multimedia Scheduling...
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "NetworkThrottlingIndex" /t REG_DWORD /d 4294967295 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "SystemResponsiveness" /t REG_DWORD /d 10 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "GPU Priority" /t REG_DWORD /d 8 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Priority" /t REG_DWORD /d 6 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Scheduling Category" /t REG_SZ /d "High" /f >nul

echo - Disabling Background Telemetry ^& Game DVR...
reg add "HKCU\System\GameConfigStore" /v "GameDVR_Enabled" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR" /v "AllowGameDVR" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v "AllowTelemetry" /t REG_DWORD /d 0 /f >nul

echo.
echo [OK] Registry optimization complete! (A PC restart is recommended)
if "%run_all%"=="1" goto :eof
echo.
pause
goto MENU


:: ========================================================
:: RUN ALL FIXES
:: ========================================================
:RUN_ALL
set "run_all=1"
call :FIREWALL
call :CURSOR
call :RAM
call :NETWORK
call :STARTUP
call :REGISTRY
set "run_all="
cls
color 0A
echo ========================================================
echo          ALL FIXES COMPLETED
echo ========================================================
echo.
echo [OK] All six fixes have finished.
echo A PC restart is recommended.
echo.
pause
goto MENU