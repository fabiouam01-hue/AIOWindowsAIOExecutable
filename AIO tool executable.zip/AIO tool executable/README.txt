﻿AIOtool for Windows 11
======================

Files
- AIOtool.exe: signed launcher. Double-click to open; Windows will request administrator approval.
- AIOtool-source.bat: the batch script embedded in the executable. Its administrator check uses fltmc so it does not depend on the Server service being enabled.
- AIOtool-signing.cer: the public certificate used for this local build. It does not contain the private signing key.

Windows trust
The executable is signed with a self-signed SHA-256 code-signing certificate valid through 2036-11-15. Windows can verify the signature, but the signer is not a public certificate authority, so Windows may show Unknown publisher and SmartScreen may still show an unfamiliar-app warning. A signature does not create SmartScreen reputation.

If you trust this specific build and want Windows to recognize this local signer, install AIOtool-signing.cer for Current User into both Trusted Root Certification Authorities and Trusted Publishers. This trusts code signed by this certificate on this Windows account. Do not install it if you do not trust the executable. For public or managed distribution, use an organization or public CA-issued code-signing certificate and timestamp the signature.

Local certificate store
The signing certificate was created in Current User > Personal to sign this executable. Its thumbprint is DDFCF78CC520D20010547241C4C1BE67C02EE1C6. It was not added to Trusted Root Certification Authorities or Trusted Publishers. If you want to remove the signing key later, open certmgr.msc, go to Personal > Certificates, find that thumbprint, and delete the certificate.

What the tool changes
The menu changes Windows Firewall rules, cursor settings, memory/network settings, startup services, and registry values; it also clears temporary files. Option 7 runs all six fix groups. Review AIOtool-source.bat before choosing options.

The launcher extracts the embedded batch file into a unique folder under %LOCALAPPDATA% while it runs, then removes that folder when the menu exits.